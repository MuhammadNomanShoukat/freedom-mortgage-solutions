import React from "react"


const HomeValue = () => {
    return(
        <h1>HomeValue</h1>
    )
}

export default HomeValue;