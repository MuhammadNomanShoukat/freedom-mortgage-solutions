import React from "react"


const Reviews = () => {
    return(
        <h1>Reviews</h1>
    )
}

export default Reviews;