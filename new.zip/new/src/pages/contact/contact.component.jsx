import React from "react"


const ContactUs = () => {
    return(
        <h1>ContactUs</h1>
    )
}

export default ContactUs;